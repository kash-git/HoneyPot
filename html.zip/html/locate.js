$('.wareImg').click(function () {
    console.log("HELLOOOO");
    window.open('https://www.google.com/maps/place/GOA+SCIENCE+CENTRE+%26+PLANETARIUM,+MIRAMAR/@15.4774432,73.8067495,17z/data=!3m1!4b1!4m5!3m4!1s0x3bbfc0c2fd09e275:0x42b197ed4c47a2bf!8m2!3d15.4774432!4d73.8089382')

})

function whole() {
    console.log('HEllllooowowowowowo');
    window.open('https://www.google.com/maps/place/Albamar+Colony,+Miramar,+Panaji,+Goa+403001/@15.4835188,73.8105577,17z/data=!3m1!4b1!4m5!3m4!1s0x3bbfc0e9a75b32cd:0x18deb1931926548e!8m2!3d15.483064!4d73.8104765')
}



function retail() {
    console.log('jdjdlsjfksj');
    window.open('https://www.google.com/maps/place/Caranzalem,+Taleigao,+Goa/@15.4674463,73.8092525,15z/data=!3m1!4b1!4m5!3m4!1s0x3bbfc0d1d23283c5:0xad06f34021c3b573!8m2!3d15.4726075!4d73.8154394')

}

